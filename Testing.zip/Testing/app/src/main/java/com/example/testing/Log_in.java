package com.example.testing;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Log_in extends AppCompatActivity {
//Welcome page
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
    }
}